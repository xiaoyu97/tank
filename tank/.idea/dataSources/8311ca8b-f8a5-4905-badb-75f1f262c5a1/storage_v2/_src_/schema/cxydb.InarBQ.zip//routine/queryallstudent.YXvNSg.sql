create
    definer = root@`%` procedure queryallstudent()
begin
 select * from student;
end;

